USE practica8;
CREATE TABLE professor
(
	id INT NOT NULL AUTO_INCREMENT,
	first_name VARCHAR(70) NOT NULL,
	last_name VARCHAR(70) NOT NULL,
	birth_date DATE NOT NULL,
	city VARCHAR(100),
	salary DECIMAL NOT NULL,
	PRIMARY KEY(id)
)

ENGINE InnoDB;

INSERT INTO professor (first_name, last_name, birth_date, city, salary)
VALUES ('Omar', 'Choquehuallpa', '2003-02-17', 'Cochabamba', 2000.50 );

INSERT INTO professor (first_name, last_name, birth_date, city, salary)
VALUES ('Andy', 'Cadima', '2002-02-13', 'Santa Cruz', 9000.30 );

INSERT INTO professor (first_name, last_name, birth_date, city, salary)
VALUES ('Annie', 'Perry', '2003-09-20', 'Cochabamba', 10000.87 );

SELECT id, first_name AS firstName, last_name AS lastName, birth_date AS birthDate, city, salary
FROM professor;